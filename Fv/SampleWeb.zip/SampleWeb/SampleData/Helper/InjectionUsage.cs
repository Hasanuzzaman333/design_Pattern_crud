﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleData.Helper
{
    public enum InjectionUsages { Fields, Properties }
}
